import mongoose from 'mongoose';
import Steam from './callSteamAPI';

import Game from '../models/game';
import Friend from '../models/friend';
import User from '../models/user';

// Steam.getFriends
// Steam.getGames

let db = {
    async saveGames(steamid, games) {
        if (typeof(games) !== "array") {
            games = [games];
        }

        let savedGamesCount = 0;

        await games.forEach(game => {
            let { appid, name, playtime_forever, img_logo_url, img_icon_url } = game;
            
            Game.find({appid}, (err, results) => {
                if (err) throw err;
                if (results.length === 0) {
                    let newGame = new Game({ appid, name, playtime_forever, img_logo_url, img_icon_url });
                    
                    newGame.save(err => {
                        if (err) throw err;
                        console.log(`Game ${appid} has been saved!`);
                        savedGamesCount += 1;
                    });
                }
            });
        });

        console.log(`Successfully saved ${savedGamesCount} ${savedGamesCount > 1 || savedGamesCount === 0? 'games' : 'game'}.`);
        return true;
    },
    async saveFriends(steamid, friends) {
        if (typeof(friends) !== "array") {
            friends = [friends];
        }

        let savedFriendsCount = 0;

        await friends.forEach(friend => {
            let { steamid, name } = friend;

            Friend.find({steamid}, (err, results) => {
                if (err) throw err;
                if (results.length === 0) {
                    let newFriend = new Friend({ steamid, name });

                    newFriend.save(err => {
                        if (err) throw err;
                        console.log(`Friend ${name} has been saved!`);
                        savedFriendsCount += 1;
                    });
                }
            });
        });

        console.log(`Successfully saved ${savedFriendsCount} ${savedFriendsCount > 1 || savedFriendsCount === 0? 'friends' : 'friend'}.`)
        return true;
    },
    async saveUser(steamid, name, games = [], friends = []) {
        if (typeof(games) !== "array") {
            games = [games];
        }
        if (typeof(friends) !== "array") {
            friends = [friends];
        }

        await User.find({steamid}, (err, results) => {
            if (err) throw err;    

            if (results.length === 0) {
                let newGames;
                let newFriends;

                games.forEach(game => {
                    newGames.push({ appid, playtime_forever });
                });

                friends.forEach(friend => {
                    newFriends.push({ steamid, friend_since });
                });

                let newUser = User({ name, steamid, games: newGames, friends: newFriends });
                newUser.save(err => {
                    if (err) throw err;
                    console.log(`Saved user ${name}, with steamid ${steamid}`);
                });
            } else {
                let user = results[0];
                let newGames = user.games;
                let newFriends = user.friends;

                games.forEach(game => {
                    newGames.push({ appid, playtime_forever });
                });

                friends.forEach(friend => {
                    newFriends.push({ steamid, friend_since });
                });

                user.save(err => {
                    if (err) throw err;
                    console.log(`Updated user ${name}, with steamid ${steamid}.`);
                });
            }
        });

        return true;
    },
    async getGameDetails(appid) {
        await Game.find({appid}, (err, results) => {
            if (results.length) {
                let game = results[0];
                return game;
            } else {
                return false;
            }
        });
    },
    async getUser(steamid) {
        await User.find({steamid}, (err, results) => {
            if (results.length) {
                let user = results[0];
                return user;
            } else {
                return false;
            }
        });
    }
}

export default db;

/*

Tank.findById(id, function (err, tank) {
  if (err) return handleError(err);

  tank.set({ size: 'large' });
  tank.save(function (err, updatedTank) {
    if (err) return handleError(err);
    res.send(updatedTank);
  });
});


    User (steamid)
    - games
        - game
            - appid
            - name
            - playtime_forever
            - img_logo_url
            - img_icon_url
            - friends
        - friend
            - steamid
            - relationship
            - friend_since
*/