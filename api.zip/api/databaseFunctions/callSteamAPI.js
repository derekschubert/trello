import fetch from 'node-fetch';

let Steam =  {
    buildUrl(properties) {
        // http://api.steampowered.com/ISteamUser/GetFriendList/v0001/?key=BF8F13E33F4F9BEFAD986381432B724F&steamid=76561198251639068&relationship=friend
        // &format=json&input_json={"steamid":76561197972495328}

        let { steamInterface,
            method,
            optionals = null,
            json = null,
            format = "json",
            key = "BF8F13E33F4F9BEFAD986381432B724F",
            version = "0001" } = properties;

        let baseUrl = "http://api.steampowered.com";
        let url = `${baseUrl}/${steamInterface}/${method}/v${version}/?key=${key}&format=${format}`;

        if (optionals) {
            optionals.forEach(o => {
                url += `&${o}`;
            });
        }

        if (json) {
            let input_json = "&input_json={";
            let needsComma = false;

            for (let prop in json) {
                if (!needsComma) {
                    needsComma = true;
                } else {
                    input_json += ",";
                }

                if (typeof(json[prop]) == "string") {
                    input_json += `"${prop}": "${json[prop]}"`;
                } else {
                    input_json += `"${prop}": ${json[prop]}`;
                }
            }

            url += `${input_json}}`;
        }

        console.log(url);
        return url;
    },
    getGames: async function(steamid) {
        let urlProperties = {
            steamInterface: 'IPlayerService', 
            method: 'GetOwnedGames',
            optionals: [
                "steamid=76561198251639068",
                "include_appinfo=1",
                "include_played_free_games=1"
            ]
        };
        
        let url = this.buildUrl(urlProperties);

        console.log("Finding Steam Games...");

        let response = await fetch(url);
        let data = await response.json();

        let game_count = data.response.game_count;
        let games = data.response.games;

        console.group(`You have ${game_count} games.`);
        games.forEach(game => {
            console.log(game);
        });
        console.groupEnd();

        return games;
    },
    getFriends: async function(steamid) {
        let urlProperties = {
            steamInterface: 'ISteamUser', 
            method: 'GetFriendList',
            optionals: [
                "steamid=76561198251639068",
                "relationship=friend"
            ]
        };

        let url = this.buildUrl(urlProperties);

        console.log("Finding Steam Friends via API");

        let response = await fetch(url);
        let data = await response.json();     

        let friends = data.friendslist.friends;

        console.group("Friends:");
        friends.forEach(friend => {
            console.log(friend);
        });
        console.groupEnd();

        return friends;
    },
    getUserInformation: async function(steamid) {
        
    }
}

export default Steam;